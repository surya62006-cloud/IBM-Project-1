
import os, requests, streamlit as st, pandas as pd

API_URL = os.getenv("API_URL", "http://localhost:8000")

st.set_page_config(page_title="Smart City Assistant", layout="wide")
st.title("Sustainable Smart City Assistant")

tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
    "City Health", "Citizen Feedback", "Summarize", "Eco-Advice", "Anomalies", "KPI", "Chat"
])

with tab1:
    st.subheader("City Health Metrics")
    ward = st.text_input("Ward", "W-01")
    metric = st.selectbox("Metric", ["pm25","pm10","water_quality","noise"])
    value = st.number_input("Value", value=50.0)
    unit = st.text_input("Unit","index")
    if st.button("Add Metric"):
        r = requests.post(f"{API_URL}/api/health/", json={"ward":ward,"metric":metric,"value":value,"unit":unit})
        st.write(r.json())
    if st.button("Refresh Metrics"):
        r = requests.get(f"{API_URL}/api/health/")
        st.dataframe(pd.DataFrame(r.json()))

with tab2:
    st.subheader("Citizen Feedback")
    name = st.text_input("Your name","Anonymous")
    msg = st.text_area("Message","")
    if st.button("Submit"):
        r = requests.post(f"{API_URL}/api/feedback/", json={"citizen":name,"message":msg})
        st.write("Saved:", r.json())
    r = requests.get(f"{API_URL}/api/feedback/")
    st.dataframe(pd.DataFrame(r.json()))

with tab3:
    st.subheader("Summarize")
    text = st.text_area("Text to summarize","Paste long text here")
    ratio = st.slider("Ratio",0.1,0.9,0.25)
    if st.button("Summarize"):
        r = requests.post(f"{API_URL}/api/summarize/", json={"text":text,"ratio":ratio})
        st.write(r.json())

with tab4:
    st.subheader("Eco Advice")
    topic = st.text_input("Topic","energy")
    if st.button("Get Advice"):
        r = requests.post(f"{API_URL}/api/eco/", json={"topic":topic})
        st.write(r.json())

with tab5:
    st.subheader("Anomalies")
    vals = st.text_input("Comma values", "10,11,12,50,11,10")
    z = st.slider("Z threshold",1.5,5.0,3.0)
    if st.button("Detect"):
        series = [float(v.strip()) for v in vals.split(",") if v.strip()]
        r = requests.post(f"{API_URL}/api/anomalies/", json={"values":series,"z_thresh":z})
        st.write(r.json())

with tab6:
    st.subheader("KPI Forecast")
    vals = st.text_input("Values","100,110,120,130,140")
    horizon = st.number_input("Horizon", value=7)
    if st.button("Forecast"):
        series = [float(v.strip()) for v in vals.split(",") if v.strip()]
        r = requests.post(f"{API_URL}/api/kpi/", json={"series":series,"horizon":horizon})
        st.write(r.json())

with tab7:
    st.subheader("Chat (watsonx Granite)")
    msg = st.text_input("Message","How to reduce PM2.5?")
    if st.button("Ask"):
        r = requests.post(f"{API_URL}/api/chat/", json={"message":msg,"history":[]} )
        st.write(r.json())
