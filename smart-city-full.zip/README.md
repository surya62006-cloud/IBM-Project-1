
# Sustainable Smart City Assistant (Full)
## What's included
- FastAPI backend (app/)
- Streamlit frontend (frontend/streamlit_app.py)
- Pinecone adapter and watsonx adapter (use env vars in .env)
- SQLite DB via SQLAlchemy (smart_city.db created automatically)
- .env.sample for configuration

## Quickstart (Windows)
1. Extract the zip to a folder, open PowerShell there.
2. Create venv and activate:
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
3. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
4. Copy `.env.sample` to `.env` and fill keys (or set env vars manually).
5. Start backend:
   ```powershell
   uvicorn app.main:app --reload --port 8000
   ```
6. In a new terminal (with venv), start frontend:
   ```powershell
   streamlit run frontend/streamlit_app.py
   ```
7. Open http://localhost:8501 for the dashboard.
