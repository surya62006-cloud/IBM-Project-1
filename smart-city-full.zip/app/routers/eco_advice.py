
from fastapi import APIRouter
from ..schemas import EcoQuery

router = APIRouter()

RULES = {
    "water":[
        "Fix leaks and install low-flow fixtures.",
        "Harvest rainwater for landscaping."
    ],
    "energy":[
        "Switch street lights to LED with smart dimming.",
        "Promote rooftop solar."
    ],
    "waste":[
        "Segregated collection and composting.",
        "Pay-as-you-throw incentives."
    ]
}

@router.post("/")
def eco(req: EcoQuery):
    k = req.topic.strip().lower()
    for key in RULES:
        if key in k:
            return {"topic": key, "advice": RULES[key]}
    return {"topic":"general", "advice": RULES["energy"] + RULES["water"][:1]}
