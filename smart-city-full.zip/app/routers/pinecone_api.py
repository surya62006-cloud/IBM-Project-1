
import os
from fastapi import APIRouter
try:
    import pinecone
except Exception:
    pinecone = None
router = APIRouter()

@router.get("/status")
def status():
    if pinecone is None:
        return {"status":"pinecone-client not installed"}
    key = os.getenv("PINECONE_API_KEY","")
    env = os.getenv("PINECONE_ENV","")
    if not key:
        return {"status":"no-api-key"}
    pinecone.init(api_key=key, environment=env)
    return {"status":"ok"}
