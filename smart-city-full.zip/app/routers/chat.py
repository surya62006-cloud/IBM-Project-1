
import os, requests
from fastapi import APIRouter
from ..schemas import ChatRequest, ChatResponse

router = APIRouter()

def watsonx_generate(prompt: str) -> str:
    api_key = os.getenv("WATSONX_API_KEY", "")
    endpoint = os.getenv("WATSONX_TEXT_GEN_URL", "")
    model_id = os.getenv("WATSONX_MODEL_ID", "ibm/granite-13b-chat-v2")
    if not api_key or not endpoint:
        return "Granite placeholder (no API key configured): " + prompt[:200]
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {"model_id": model_id, "input": prompt, "parameters": {"max_new_tokens":256}}
    r = requests.post(endpoint, json=payload, headers=headers, timeout=30)
    r.raise_for_status()
    data = r.json()
    if isinstance(data, dict):
        for k in ("generated_text","output","result","text"):
            if k in data:
                return data[k] if isinstance(data[k], str) else str(data[k])
    return str(data)

@router.post("/", response_model=ChatResponse)
def chat(req: ChatRequest):
    prompt = req.message
    reply = watsonx_generate(prompt)
    return ChatResponse(reply=reply)
