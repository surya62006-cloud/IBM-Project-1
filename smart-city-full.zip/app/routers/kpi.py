
import numpy as np
from fastapi import APIRouter
from ..schemas import KPIRequest, KPIResponse

router = APIRouter()

@router.post("/", response_model=KPIResponse)
def forecast(req: KPIRequest):
    series = np.array(req.series, dtype=float)
    window = min(7, len(series)) if len(series)>0 else 1
    ma = np.convolve(series, np.ones(window)/window, mode='valid') if len(series)>0 else [0.0]
    last = float(ma[-1]) if len(ma)>0 else float(series[-1]) if len(series)>0 else 0.0
    return KPIResponse(forecast=[last for _ in range(req.horizon)])
