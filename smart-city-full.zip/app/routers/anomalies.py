
import numpy as np
from fastapi import APIRouter
from ..schemas import AnomalyRequest, AnomalyResponse

router = APIRouter()

@router.post("/", response_model=AnomalyResponse)
def detect(req: AnomalyRequest):
    x = np.array(req.values, dtype=float)
    if len(x)<2:
        return AnomalyResponse(anomalies=[])
    z = (x - x.mean()) / (x.std()+1e-9)
    idx = [int(i) for i,zi in enumerate(z) if abs(zi)>req.z_thresh]
    return AnomalyResponse(anomalies=idx)
