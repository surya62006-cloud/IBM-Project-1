
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from ..db import SessionLocal
from .. import models
from ..schemas import HealthMetricIn, HealthMetricOut

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=HealthMetricOut)
def add_metric(item: HealthMetricIn, db: Session = Depends(get_db)):
    m = models.HealthMetric(ward=item.ward, metric=item.metric, value=item.value, unit=item.unit)
    db.add(m); db.commit(); db.refresh(m)
    return m

@router.get("/", response_model=List[HealthMetricOut])
def list_metrics(db: Session = Depends(get_db), ward: str = None, metric: str = None, limit: int = 200):
    q = db.query(models.HealthMetric)
    if ward: q = q.filter(models.HealthMetric.ward == ward)
    if metric: q = q.filter(models.HealthMetric.metric == metric)
    return q.order_by(models.HealthMetric.recorded_at.desc()).limit(limit).all()
