
import re
from fastapi import APIRouter
from ..schemas import SummarizeRequest

router = APIRouter()

def simple_freq_summary(text, ratio=0.25):
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    words = re.findall(r"[A-Za-z']+", text.lower())
    stop = set('a an the and or but if then while to of in on at for from with is are was were be have'.split())
    freq = {}
    for w in words:
        if w in stop: continue
        freq[w] = freq.get(w,0)+1
    scores = []
    for s in sentences:
        s_words = re.findall(r"[A-Za-z']+", s.lower())
        score = sum(freq.get(w,0) for w in s_words) / (len(s_words)+1e-9)
        scores.append((score,s))
    keep = max(1, int(len(sentences)*ratio))
    top = [s for _,s in sorted(scores, key=lambda t:t[0], reverse=True)[:keep]]
    top.sort(key=lambda s: sentences.index(s))
    return ' '.join(top)

@router.post("/")
def summarize(req: SummarizeRequest):
    return {"summary": simple_freq_summary(req.text, req.ratio)}
