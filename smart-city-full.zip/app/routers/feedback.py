
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import SessionLocal
from .. import models
from ..schemas import FeedbackIn, FeedbackOut
from typing import List

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=FeedbackOut)
def submit_feedback(item: FeedbackIn, db: Session = Depends(get_db)):
    fb = models.Feedback(citizen=item.citizen, message=item.message)
    db.add(fb)
    db.commit()
    db.refresh(fb)
    return fb

@router.get("/", response_model=List[FeedbackOut])
def list_feedback(db: Session = Depends(get_db)):
    return db.query(models.Feedback).order_by(models.Feedback.created_at.desc()).limit(200).all()
