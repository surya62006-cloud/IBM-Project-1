
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routers import chat, kpi, anomalies, feedback, summarize, eco_advice, health, pinecone_api
from .db import init_db
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="Sustainable Smart City Assistant (Full)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat.router, prefix="/api/chat", tags=["Chat"])
app.include_router(kpi.router, prefix="/api/kpi", tags=["KPI"])
app.include_router(anomalies.router, prefix="/api/anomalies", tags=["Anomalies"])
app.include_router(feedback.router, prefix="/api/feedback", tags=["Feedback"])
app.include_router(summarize.router, prefix="/api/summarize", tags=["Summarize"])
app.include_router(eco_advice.router, prefix="/api/eco", tags=["Eco"])
app.include_router(health.router, prefix="/api/health", tags=["Health"])
app.include_router(pinecone_api.router, prefix="/api/pinecone", tags=["Pinecone"])

@app.get("/api/healthcheck")
def healthcheck():
    return {"status": "ok"}

@app.on_event("startup")
def on_startup():
    init_db()
