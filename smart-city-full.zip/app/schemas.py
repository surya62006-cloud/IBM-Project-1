
from pydantic import BaseModel
from typing import Optional, List

class ChatRequest(BaseModel):
    message: str
    history: Optional[list] = []

class ChatResponse(BaseModel):
    reply: str

class FeedbackIn(BaseModel):
    citizen: str
    message: str

class FeedbackOut(BaseModel):
    id: int
    citizen: str
    message: str
    created_at: str
    class Config:
        orm_mode = True

class KPIRequest(BaseModel):
    series: list
    horizon: int = 7

class KPIResponse(BaseModel):
    forecast: list

class AnomalyRequest(BaseModel):
    values: list
    z_thresh: float = 3.0

class AnomalyResponse(BaseModel):
    anomalies: list

class SummarizeRequest(BaseModel):
    text: str
    ratio: float = 0.25

class EcoQuery(BaseModel):
    topic: str

class HealthMetricIn(BaseModel):
    ward: str
    metric: str
    value: float
    unit: str = ""

class HealthMetricOut(BaseModel):
    id: int
    ward: str
    metric: str
    value: float
    unit: str
    recorded_at: str
    class Config:
        orm_mode = True
