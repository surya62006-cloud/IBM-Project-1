
from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from sqlalchemy.sql import func
from .db import Base

class Feedback(Base):
    __tablename__ = "feedback"
    id = Column(Integer, primary_key=True, index=True)
    citizen = Column(String, index=True)
    message = Column(Text)
    created_at = Column(DateTime, server_default=func.now())

class HealthMetric(Base):
    __tablename__ = "health_metrics"
    id = Column(Integer, primary_key=True, index=True)
    ward = Column(String, index=True)
    metric = Column(String, index=True)
    value = Column(Float)
    unit = Column(String, default="")
    recorded_at = Column(DateTime, server_default=func.now())
